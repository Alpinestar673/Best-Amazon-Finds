# Blogger (Blogspot) Setup Guide - Amazon Finds

Follow these steps to set up your high-converting Amazon Influencer website on Blogger.

## 1. Create a New Blog
1. Go to [Blogger.com](https://www.blogger.com) and sign in with your Google account.
2. Click **New Blog**.
3. Enter a title (e.g., "Amazon Finds") and a domain (e.g., `myamazonfinds.blogspot.com`).
4. Choose any basic theme for now.

## 2. Install the Custom Theme
1. In the Blogger dashboard, click **Theme**.
2. Click the arrow next to the **Customize** button and select **Edit HTML**.
3. Open the `blogger-theme.xml` file provided in this project.
4. Copy the entire content of `blogger-theme.xml`.
5. In the Blogger HTML editor, delete everything and paste the new code.
6. Click the **Save** icon (top right).

## 3. Configure Categories (Labels)
1. Go to **Layout**.
2. Find the **Categories** or **Labels** widget in the sidebar.
3. Click **Edit** and ensure it's set to show "All Labels".
4. As you create posts, add labels like:
   - `Home Essentials`
   - `Kitchen Essentials`
   - `Best Deals`
   - `Gift Ideas`

## 4. Creating a Product Post
1. Click **New Post**.
2. **Title:** Use an SEO-optimized title (e.g., "This Electric Scrubber Saves Hours of Cleaning").
3. **Content:**
   - Upload the product image.
   - Add a curiosity hook: *“You didn’t know you needed this”*
   - Add a short description (2-3 lines).
   - Add bullet benefits.
4. **CTA Button:**
   - Switch to **HTML view** in the post editor.
   - Add this code for the button:
     ```html
     <a href="YOUR_AMAZON_AFFILIATE_LINK" target="_blank" class="cta-button">👉 Check Price on Amazon</a>
     ```
5. **Labels:** Add the appropriate category label.
6. **Publish.**

## 5. Add Trending Section
1. Go to **Layout**.
2. Find the **Sidebar** section.
3. Click **Add a Gadget**.
4. Select **Popular Posts**.
5. Title it: `🔥 Trending Amazon Finds`.
6. Set it to show "Last 30 days" and "5 posts".

## 6. Mobile Optimization Tips
- Keep images large and clear.
- Use short, punchy hooks.
- Ensure your affiliate links open in a new tab.

## 7. Monetization
- Replace `YOUR_AMAZON_AFFILIATE_LINK` with your actual Amazon Associate link.
- Use your tracking ID to monitor clicks in the Amazon Associates dashboard.

---
**Final Goal:** Your site is now optimized for viral traffic and high conversion rates!
