/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  TrendingUp, 
  Heart, 
  ShoppingCart, 
  ChevronRight, 
  Star, 
  Filter, 
  Menu, 
  X, 
  Play, 
  BarChart3, 
  Mail, 
  Clock, 
  ArrowUpRight,
  Flame,
  Zap,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Product, Category, CATEGORIES, MOCK_PRODUCTS } from './types';
import { VIDEO_SCRIPTS } from './scripts';

import { 
  auth, 
  db, 
  loginWithGoogle, 
  logout, 
  handleFirestoreError, 
  OperationType 
} from './firebase';
import { 
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  onSnapshot, 
  updateDoc, 
  increment, 
  query, 
  where,
  writeBatch
} from 'firebase/firestore';

// --- Components ---

const Badge = ({ children, variant = 'default' }: { children: React.ReactNode, variant?: 'default' | 'trending' | 'deal' | 'bestseller' }) => {
  const styles = {
    default: 'bg-gray-100 text-gray-800',
    trending: 'bg-orange-100 text-orange-600',
    deal: 'bg-red-100 text-red-600',
    bestseller: 'bg-yellow-100 text-yellow-700'
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${styles[variant]}`}>
      {children}
    </span>
  );
};

const ProductCard = ({ product, onWishlist, isWishlisted, onTrackClick, onTrackView, onCompare }: { 
  product: Product, 
  onWishlist: (id: string) => void, 
  isWishlisted: boolean,
  onTrackClick: (id: string) => void,
  onTrackView: (id: string) => void,
  onCompare: (id: string) => void,
  key?: string | number
}) => {
  const [isHovered, setIsHovered] = useState(false);
  useEffect(() => {
    onTrackView(product.id);
  }, []);

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group bg-white border border-gray-100 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col h-full relative"
    >
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img 
          src={product.image} 
          alt={product.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          {product.isTrending && <Badge variant="trending">🔥 Trending</Badge>}
          {product.isBestSeller && <Badge variant="bestseller">⭐ Best Seller</Badge>}
          {product.isLimitedDeal && (
            <div className="flex flex-col gap-1">
              <Badge variant="deal">⚡ Limited Deal</Badge>
              <div className="bg-red-600 text-white text-[8px] font-black px-2 py-0.5 rounded-full animate-pulse uppercase tracking-widest">
                Ends Soon!
              </div>
            </div>
          )}
          {product.bundleProducts && <Badge variant="default">📦 Bundle Deal</Badge>}
        </div>
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          <button 
            onClick={(e) => { e.preventDefault(); onWishlist(product.id); }}
            className={`p-2 rounded-full backdrop-blur-md transition-colors ${isWishlisted ? 'bg-red-500 text-white' : 'bg-white/80 text-gray-600 hover:text-red-500'}`}
          >
            <Heart size={18} fill={isWishlisted ? 'currentColor' : 'none'} />
          </button>
          <button 
            onClick={(e) => { e.preventDefault(); onCompare(product.id); }}
            className="p-2 rounded-full bg-white/80 backdrop-blur-md text-gray-600 hover:text-orange-500 transition-colors"
            title="Compare"
          >
            <BarChart3 size={18} />
          </button>
        </div>
        {product.videoUrl && (
          <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md text-white px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1">
            <Play size={10} fill="white" /> WATCH VIDEO
          </div>
        )}
      </div>

      <div className="p-4 flex flex-col flex-grow">
        <div className="flex items-center gap-1 mb-1">
          <div className="flex text-yellow-400">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={12} fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'} />
            ))}
          </div>
          <span className="text-xs text-gray-400 font-medium">{product.rating}</span>
        </div>
        
        <h3 className="font-black text-gray-900 leading-tight mb-1 group-hover:text-orange-500 transition-colors text-lg">
          {product.title}
        </h3>
        <p className="text-sm font-bold text-orange-500 mb-2">
          “{product.hook || "You didn't know you needed this"}”
        </p>
        
        <p className="text-xs text-gray-500 mb-3 line-clamp-2 leading-relaxed">
          This viral find is a total game changer for your {product.category.toLowerCase()}. It's practical, affordable, and highly rated by thousands of shoppers.
        </p>
        
        <ul className="space-y-1.5 mb-6 flex-grow">
          {product.benefits.map((benefit, i) => (
            <li key={i} className="text-[11px] font-bold text-gray-700 flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0">
                <Zap size={10} fill="currentColor" />
              </div>
              {benefit}
            </li>
          ))}
        </ul>

        <div className="flex flex-col gap-3 mt-auto pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-black text-gray-900">${product.price}</span>
            <div className="flex items-center gap-1">
              <Star size={14} fill="#fbbf24" className="text-yellow-400" />
              <span className="text-sm font-black">{product.rating}</span>
            </div>
          </div>
          <a 
            href={product.amazonLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => onTrackClick(product.id)}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-orange-500/20 text-sm"
          >
            👉 Check Price on Amazon
          </a>
        </div>
      </div>
    </motion.div>
  );
};

const VideoFeedItem = ({ product, onTrackClick }: { product: Product, onTrackClick: (id: string) => void, key?: string | number }) => {
  return (
    <div className="h-full w-full relative bg-black snap-start flex items-center justify-center overflow-hidden">
      {/* Mock Video Background */}
      <div className="absolute inset-0 opacity-60">
        <img src={product.image} className="w-full h-full object-cover blur-xl" alt="" />
      </div>
      
      <div className="relative z-10 w-full max-w-md aspect-[9/16] bg-gray-900 rounded-3xl overflow-hidden shadow-2xl border border-white/10">
        {product.videoUrl ? (
          <video 
            src={product.videoUrl} 
            autoPlay 
            loop 
            muted 
            playsInline 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-500 to-red-600">
             <Play size={64} className="text-white opacity-50" />
          </div>
        )}
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
        
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <Badge variant="trending">🔥 Viral Find</Badge>
          <h2 className="text-2xl font-black mt-2 leading-tight">{product.title}</h2>
          <p className="text-lg font-medium text-orange-400 mt-1 italic">"{product.hook}"</p>
          
          <div className="mt-6 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-xs text-gray-400 uppercase tracking-widest font-bold">Price</span>
              <span className="text-2xl font-black">${product.price}</span>
            </div>
            <a 
              href={product.amazonLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => onTrackClick(product.id)}
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-2xl font-black flex items-center gap-2 shadow-lg shadow-orange-500/30 active:scale-95 transition-all"
            >
              SHOP ON AMAZON <ArrowUpRight size={20} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

const CountdownTimer = ({ hours: initialHours }: { hours: number }) => {
  const [timeLeft, setTimeLeft] = useState(initialHours * 3600);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const h = Math.floor(timeLeft / 3600);
  const m = Math.floor((timeLeft % 3600) / 60);
  const s = timeLeft % 60;

  return (
    <div className="flex gap-2 font-mono font-bold text-xl">
      <div className="bg-white/20 px-2 py-1 rounded">{h.toString().padStart(2, '0')}</div>
      <div className="text-white/50">:</div>
      <div className="bg-white/20 px-2 py-1 rounded">{m.toString().padStart(2, '0')}</div>
      <div className="text-white/50">:</div>
      <div className="bg-white/20 px-2 py-1 rounded">{s.toString().padStart(2, '0')}</div>
    </div>
  );
};

const ComparisonModal = ({ products, onClose }: { products: Product[], onClose: () => void }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative bg-white w-full max-w-4xl rounded-[2.5rem] overflow-hidden shadow-2xl"
      >
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-2xl font-black">Compare Finds</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><X size={24} /></button>
        </div>
        <div className="p-8 overflow-x-auto">
          <div className="grid grid-cols-3 gap-8 min-w-[600px]">
            {products.map(p => (
              <div key={p.id} className="space-y-6">
                <img src={p.image} className="w-full aspect-square object-cover rounded-2xl" alt="" />
                <div>
                  <h4 className="font-bold text-lg leading-tight">{p.title}</h4>
                  <p className="text-2xl font-black text-orange-500 mt-2">${p.price}</p>
                </div>
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Rating</span>
                    <div className="flex items-center gap-1 mt-1">
                      <Star size={14} fill="#fbbf24" className="text-yellow-400" />
                      <span className="font-bold">{p.rating}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Key Benefits</span>
                    <ul className="mt-2 space-y-1">
                      {p.benefits.map((b, i) => (
                        <li key={i} className="text-xs text-gray-600 flex items-center gap-2">
                          <div className="w-1 h-1 rounded-full bg-orange-400" />
                          {b}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <a 
                  href={p.amazonLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full bg-orange-500 text-white text-center py-3 rounded-xl font-bold hover:bg-orange-600 transition-all"
                >
                  View on Amazon
                </a>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [view, setView] = useState<'home' | 'video-feed' | 'wishlist' | 'admin'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [comparisonIds, setComparisonIds] = useState<string[]>([]);
  const [analytics, setAnalytics] = useState<{ [key: string]: { clicks: number, views: number } }>({});
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userRole, setUserRole] = useState<'admin' | 'user'>('user');
  const [isAuthReady, setIsAuthReady] = useState(false);

  // --- Firebase Integration ---

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        // Sync user profile
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        try {
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setWishlist(userData.wishlist || []);
            setUserRole(userData.role || 'user');
          } else {
            // Create new user profile
            const isDefaultAdmin = firebaseUser.email === "basavarajva@gmail.com";
            const newUserData = {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              wishlist: [],
              role: isDefaultAdmin ? 'admin' : 'user'
            };
            await setDoc(userDocRef, newUserData);
            setWishlist([]);
            setUserRole(newUserData.role as 'admin' | 'user');
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
        }
      } else {
        setWishlist([]);
        setUserRole('user');
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Fetch Products
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'products'), (snapshot) => {
      const productsData = snapshot.docs.map(doc => doc.data() as Product);
      if (productsData.length > 0) {
        setProducts(productsData);
      } else if (userRole === 'admin') {
        // Seed products if empty and user is admin
        seedProducts();
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'products');
    });
    return () => unsubscribe();
  }, [userRole]);

  // Fetch Analytics
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'analytics'), (snapshot) => {
      const analyticsData: { [key: string]: { clicks: number, views: number } } = {};
      snapshot.docs.forEach(doc => {
        analyticsData[doc.id] = doc.data() as { clicks: number, views: number };
      });
      setAnalytics(analyticsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'analytics');
    });
    return () => unsubscribe();
  }, []);

  const seedProducts = async () => {
    const batch = writeBatch(db);
    MOCK_PRODUCTS.forEach(product => {
      const docRef = doc(db, 'products', product.id);
      batch.set(docRef, product);
    });
    try {
      await batch.commit();
      console.log('Products seeded successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'products (seeding)');
    }
  };

  const trackClick = async (id: string) => {
    const analyticsRef = doc(db, 'analytics', id);
    try {
      await setDoc(analyticsRef, { 
        id, 
        clicks: increment(1), 
        views: increment(0) 
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `analytics/${id}`);
    }
  };

  const trackView = async (id: string) => {
    const analyticsRef = doc(db, 'analytics', id);
    try {
      await setDoc(analyticsRef, { 
        id, 
        clicks: increment(0), 
        views: increment(1) 
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `analytics/${id}`);
    }
  };

  const toggleWishlist = async (id: string) => {
    if (!user) {
      loginWithGoogle();
      return;
    }

    const newWishlist = wishlist.includes(id) 
      ? wishlist.filter(i => i !== id) 
      : [...wishlist, id];
    
    setWishlist(newWishlist);

    const userDocRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(userDocRef, { wishlist: newWishlist });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const toggleComparison = (id: string) => {
    setComparisonIds(prev => {
      if (prev.includes(id)) return prev.filter(i => i !== id);
      if (prev.length >= 3) return [...prev.slice(1), id];
      return [...prev, id];
    });
  };

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           p.hook.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory, products]);

  const trendingProducts = useMemo(() => {
    return [...products].sort((a, b) => (analytics[b.id]?.clicks || 0) - (analytics[a.id]?.clicks || 0)).slice(0, 10);
  }, [analytics, products]);

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans selection:bg-orange-100 selection:text-orange-600">
      {/* --- Navigation --- */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('home')}>
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-orange-500/20">
              <ShoppingCart size={24} strokeWidth={2.5} />
            </div>
            <span className="text-xl font-black tracking-tighter hidden sm:block">AMAZON<span className="text-orange-500">FINDS</span></span>
          </div>

          <div className="flex-grow max-w-xl relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-orange-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search viral finds..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-100 border-none rounded-2xl py-2.5 pl-11 pr-4 text-sm focus:ring-2 focus:ring-orange-500/20 focus:bg-white transition-all outline-none"
            />
          </div>

          <div className="flex items-center gap-2">
            {user ? (
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex flex-col items-end">
                  <span className="text-[10px] font-black text-gray-900 uppercase tracking-tighter">{user.displayName?.split(' ')[0]}</span>
                  <span className="text-[8px] text-orange-500 font-bold uppercase tracking-widest">{userRole}</span>
                </div>
                <button 
                  onClick={() => logout()}
                  className="p-2.5 rounded-xl hover:bg-gray-100 text-gray-400 hover:text-gray-900 transition-all"
                  title="Logout"
                >
                  <X size={20} />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => loginWithGoogle()}
                className="hidden sm:flex bg-gray-900 text-white px-5 py-2.5 rounded-xl text-xs font-black hover:bg-black transition-all active:scale-95"
              >
                LOGIN
              </button>
            )}
            <button 
              onClick={() => setView('video-feed')}
              className={`p-2.5 rounded-xl transition-all ${view === 'video-feed' ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' : 'hover:bg-gray-100 text-gray-600'}`}
              title="Video Feed"
            >
              <Play size={20} fill={view === 'video-feed' ? 'white' : 'none'} />
            </button>
            <button 
              onClick={() => setView('wishlist')}
              className={`p-2.5 rounded-xl transition-all relative ${view === 'wishlist' ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' : 'hover:bg-gray-100 text-gray-600'}`}
              title="Wishlist"
            >
              <Heart size={20} fill={view === 'wishlist' ? 'white' : 'none'} />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                  {wishlist.length}
                </span>
              )}
            </button>
            {userRole === 'admin' && (
              <button 
                onClick={() => setView('admin')}
                className={`p-2.5 rounded-xl transition-all ${view === 'admin' ? 'bg-orange-500 text-white' : 'hover:bg-gray-100 text-gray-600'}`}
                title="Analytics"
              >
                <BarChart3 size={20} />
              </button>
            )}
          </div>
        </div>

        {/* Categories Bar */}
        <div className="border-t border-gray-50 overflow-x-auto no-scrollbar">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2">
            <button 
              onClick={() => setSelectedCategory('All')}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all ${selectedCategory === 'All' ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              All Finds
            </button>
            {CATEGORIES.map(cat => (
              <button 
                key={cat.name}
                onClick={() => setSelectedCategory(cat.name)}
                className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 transition-all ${selectedCategory === cat.name ? 'bg-orange-500 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                <cat.icon size={14} />
                {cat.name}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-12"
            >
              {/* Hero Section */}
              {!searchQuery && selectedCategory === 'All' && (
                <section className="relative rounded-[2.5rem] overflow-hidden bg-gray-900 text-white p-8 md:p-16">
                  <div className="absolute inset-0 opacity-20">
                    <div className="grid grid-cols-6 gap-4 rotate-12 scale-150">
                      {MOCK_PRODUCTS.slice(0, 12).map((p, i) => (
                        <img key={i} src={p.image} className="aspect-square object-cover rounded-2xl" alt="" />
                      ))}
                    </div>
                  </div>
                  <div className="relative z-10 max-w-2xl">
                    <Badge variant="trending">New Viral Finds Daily</Badge>
                    <h1 className="text-4xl md:text-6xl font-black mt-6 leading-tight">
                      Amazon Finds That Actually <span className="text-orange-500">Make Life Easier</span>
                    </h1>
                    <p className="text-lg md:text-xl text-gray-400 mt-6 font-medium">
                      Viral, useful & affordable products you didn't know you needed. Hand-picked for maximum utility.
                    </p>
                    <div className="flex flex-wrap gap-4 mt-10">
                      <button 
                        onClick={() => {
                          const el = document.getElementById('explore');
                          el?.scrollIntoView({ behavior: 'smooth' });
                        }}
                        className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-2xl font-black flex items-center gap-2 transition-all active:scale-95 shadow-xl shadow-orange-500/20"
                      >
                        Start Exploring <ChevronRight size={20} />
                      </button>
                      <button 
                        onClick={() => setView('video-feed')}
                        className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white px-8 py-4 rounded-2xl font-black flex items-center gap-2 transition-all active:scale-95"
                      >
                        Watch Feed <Play size={20} fill="white" />
                      </button>
                    </div>
                  </div>
                </section>
              )}

              {/* Trending Section */}
              {!searchQuery && selectedCategory === 'All' && (
                <section>
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-orange-500 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/20">
                        <Flame size={24} fill="currentColor" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-black">🔥 Trending Amazon Finds</h2>
                        <p className="text-sm text-gray-500">Viral products everyone is talking about right now.</p>
                      </div>
                    </div>
                    <div className="hidden sm:flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-xl">
                      <Clock size={16} className="text-orange-500" />
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Updated 5m ago</span>
                    </div>
                  </div>
                  <div className="flex gap-6 overflow-x-auto pb-8 no-scrollbar snap-x">
                    {trendingProducts.map(product => (
                      <div key={product.id} className="min-w-[320px] snap-start">
                        <ProductCard 
                          product={product} 
                          onWishlist={toggleWishlist} 
                          isWishlisted={wishlist.includes(product.id)}
                          onTrackClick={trackClick}
                          onTrackView={trackView}
                          onCompare={toggleComparison}
                        />
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Video Section */}
              {!searchQuery && selectedCategory === 'All' && (
                <section className="bg-gray-900 rounded-[3rem] p-8 md:p-16 text-white relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
                  <div className="relative z-10">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-12">
                      <div>
                        <Badge variant="trending">Watch & Shop</Badge>
                        <h2 className="text-3xl md:text-5xl font-black mt-4">Watch Before You Buy</h2>
                        <p className="text-gray-400 mt-4 max-w-xl text-lg">
                          See these products in action. Our viral video feed helps you decide if it's worth the hype.
                        </p>
                      </div>
                      <button 
                        onClick={() => setView('video-feed')}
                        className="bg-white text-gray-900 px-8 py-4 rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-orange-500 hover:text-white transition-all active:scale-95 shadow-xl"
                      >
                        Open Full Feed <Play size={20} fill="currentColor" />
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                      {products.filter(p => p.videoUrl).slice(0, 4).map(p => (
                        <div 
                          key={p.id} 
                          onClick={() => setView('video-feed')}
                          className="group relative aspect-[9/16] rounded-3xl overflow-hidden cursor-pointer border border-white/10"
                        >
                          <img src={p.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
                              <Play size={32} fill="white" />
                            </div>
                          </div>
                          <div className="absolute bottom-6 left-6 right-6">
                            <h4 className="font-bold text-white leading-tight line-clamp-2">{p.title}</h4>
                            <p className="text-orange-400 text-xs font-bold mt-2">Watch Demo →</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>
              )}

              {/* Bundle Section */}
              {!searchQuery && selectedCategory === 'All' && (
                <section className="bg-gray-50 rounded-[3rem] p-8 md:p-12">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h2 className="text-2xl font-black">Curated Bundles</h2>
                      <p className="text-gray-500 mt-1">Save more when you buy these viral combinations.</p>
                    </div>
                    <button className="text-orange-500 font-bold hover:underline">View All Bundles</button>
                  </div>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {products.filter(p => p.bundleProducts).slice(0, 2).map(bundle => (
                      <div key={bundle.id} className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-6">
                        <div className="w-full sm:w-48 aspect-square rounded-2xl overflow-hidden">
                          <img src={bundle.image} className="w-full h-full object-cover" alt="" />
                        </div>
                        <div className="flex-grow flex flex-col justify-between py-2">
                          <div>
                            <Badge variant="deal">Bundle Deal</Badge>
                            <h3 className="text-xl font-black mt-3">{bundle.title} + Essentials</h3>
                            <div className="flex items-center gap-2 mt-4">
                              <div className="flex -space-x-3">
                                {bundle.bundleProducts?.map(id => (
                                  <img 
                                    key={id} 
                                    src={products.find(p => p.id === id)?.image} 
                                    className="w-10 h-10 rounded-full border-2 border-white object-cover" 
                                    alt="" 
                                  />
                                ))}
                              </div>
                              <span className="text-xs font-bold text-gray-400 ml-2">Includes {bundle.bundleProducts?.length} additional items</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between mt-6">
                            <div className="flex flex-col">
                              <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Bundle Price</span>
                              <span className="text-2xl font-black text-orange-500">${(bundle.price * 1.8).toFixed(2)}</span>
                            </div>
                            <button className="bg-gray-900 text-white px-6 py-3 rounded-xl font-bold active:scale-95 transition-all">
                              Get Bundle
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}
              <section id="explore">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-black">
                    {selectedCategory === 'All' ? 'All Viral Finds' : selectedCategory}
                    <span className="ml-3 text-sm font-medium text-gray-400">({filteredProducts.length} items)</span>
                  </h2>
                  <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-xl">
                    <button className="p-2 bg-white rounded-lg shadow-sm text-gray-900"><Menu size={18} /></button>
                    <button className="p-2 text-gray-400 hover:text-gray-600"><Filter size={18} /></button>
                  </div>
                </div>

                {filteredProducts.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredProducts.map(product => (
                      <ProductCard 
                        key={product.id} 
                        product={product} 
                        onWishlist={toggleWishlist} 
                        isWishlisted={wishlist.includes(product.id)}
                        onTrackClick={trackClick}
                        onTrackView={trackView}
                        onCompare={toggleComparison}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 bg-gray-50 rounded-[3rem] border-2 border-dashed border-gray-200">
                    <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search size={32} className="text-gray-400" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">No finds found</h3>
                    <p className="text-gray-500 mt-2">Try searching for something else or change the category.</p>
                    <button 
                      onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
                      className="mt-6 text-orange-500 font-bold hover:underline"
                    >
                      Clear all filters
                    </button>
                  </div>
                )}
              </section>

              {/* Email Capture Section */}
              {!searchQuery && selectedCategory === 'All' && (
                <section className="bg-orange-500 rounded-[3rem] p-8 md:p-16 text-white text-center relative overflow-hidden">
                  <div className="absolute inset-0 opacity-10">
                    <div className="grid grid-cols-8 gap-4 rotate-12 scale-150">
                      {MOCK_PRODUCTS.slice(10, 26).map((p, i) => (
                        <img key={i} src={p.image} className="aspect-square object-cover rounded-2xl" alt="" />
                      ))}
                    </div>
                  </div>
                  <div className="relative z-10 max-w-2xl mx-auto">
                    <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl flex items-center justify-center mx-auto mb-8">
                      <Mail size={40} className="text-white" />
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black mb-6">Get Best Amazon Finds</h2>
                    <p className="text-orange-100 text-lg md:text-xl mb-10 font-medium">
                      Join 50,000+ shoppers who get our hand-picked viral finds delivered to their inbox every week.
                    </p>
                    {isSubscribed ? (
                      <motion.div 
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="bg-white text-orange-600 p-6 rounded-[2rem] font-black text-xl flex items-center justify-center gap-3 shadow-2xl"
                      >
                        <Zap size={24} fill="currentColor" /> You're on the list!
                      </motion.div>
                    ) : (
                      <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto" onSubmit={(e) => { e.preventDefault(); setIsSubscribed(true); }}>
                        <input 
                          type="email" 
                          placeholder="Enter your email address" 
                          required
                          className="flex-grow px-6 py-4 rounded-2xl bg-white text-gray-900 font-bold outline-none shadow-xl"
                        />
                        <button className="bg-gray-900 hover:bg-black text-white px-8 py-4 rounded-2xl font-black transition-all active:scale-95 shadow-xl">
                          Subscribe Now
                        </button>
                      </form>
                    )}
                    <p className="text-orange-200 text-xs mt-6 font-bold uppercase tracking-widest">
                      No spam. Only the best finds. Unsubscribe anytime.
                    </p>
                  </div>
                </section>
              )}

              {/* Deals & Urgency */}
              <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-red-600 rounded-[2.5rem] p-8 text-white flex flex-col justify-between min-h-[300px] relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-20 group-hover:scale-110 transition-transform">
                    <Clock size={120} />
                  </div>
                  <div>
                    <Badge variant="deal">Limited-time deal</Badge>
                    <h3 className="text-3xl font-black mt-4">Today's Flash Sale</h3>
                    <p className="text-red-100 mt-2 max-w-xs mb-6">Up to 60% off on viral home essentials. Ends in:</p>
                    <CountdownTimer hours={4.5} />
                  </div>
                  <button className="bg-white text-red-600 w-fit px-8 py-4 rounded-2xl font-black mt-8 flex items-center gap-2 shadow-xl active:scale-95 transition-all">
                    Shop Deals <ChevronRight size={18} />
                  </button>
                </div>
                <div className="bg-yellow-400 rounded-[2.5rem] p-8 text-gray-900 flex flex-col justify-between min-h-[300px] relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-20 group-hover:scale-110 transition-transform">
                    <TrendingUp size={120} />
                  </div>
                  <div>
                    <Badge variant="bestseller">Must Have</Badge>
                    <h3 className="text-3xl font-black mt-4">Best Sellers of 2026</h3>
                    <p className="text-yellow-900 mt-2 max-w-xs">The products that defined the year. See what everyone is buying.</p>
                  </div>
                  <button className="bg-gray-900 text-white w-fit px-8 py-4 rounded-2xl font-black mt-8 flex items-center gap-2 shadow-xl active:scale-95 transition-all">
                    View List <ChevronRight size={18} />
                  </button>
                </div>
              </section>
            </motion.div>
          )}

          {view === 'video-feed' && (
            <motion.div 
              key="video-feed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] bg-black h-screen w-screen overflow-y-scroll snap-y snap-mandatory no-scrollbar"
            >
              <button 
                onClick={() => setView('home')}
                className="fixed top-6 left-6 z-[70] p-3 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full text-white transition-all"
              >
                <X size={24} />
              </button>
              
              <div className="fixed top-6 right-6 z-[70] flex flex-col gap-4">
                <div className="flex flex-col items-center gap-1">
                  <button className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:text-red-500 transition-colors">
                    <Heart size={24} />
                  </button>
                  <span className="text-[10px] text-white font-bold">12.4k</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <button className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:text-orange-500 transition-colors">
                    <ArrowUpRight size={24} />
                  </button>
                  <span className="text-[10px] text-white font-bold">Share</span>
                </div>
              </div>

              <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[70] flex flex-col items-center gap-2 pointer-events-none opacity-50">
                <ChevronUp size={20} className="text-white animate-bounce" />
                <span className="text-[10px] text-white font-bold uppercase tracking-widest">Swipe for more</span>
              </div>

              {MOCK_PRODUCTS.filter(p => p.videoUrl || p.isTrending).map(product => (
                <VideoFeedItem key={product.id} product={product} onTrackClick={trackClick} />
              ))}
            </motion.div>
          )}

          {view === 'wishlist' && (
            <motion.div 
              key="wishlist"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-black flex items-center gap-3">
                  <Heart size={32} fill="currentColor" className="text-red-500" />
                  Your Wishlist
                </h2>
                <button 
                  onClick={() => setView('home')}
                  className="text-orange-500 font-bold flex items-center gap-1 hover:underline"
                >
                  Back to shopping <ChevronRight size={18} />
                </button>
              </div>

              {wishlist.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {products.filter(p => wishlist.includes(p.id)).map(product => (
                    <ProductCard 
                      key={product.id} 
                      product={product} 
                      onWishlist={toggleWishlist} 
                      isWishlisted={true}
                      onTrackClick={trackClick}
                      onTrackView={trackView}
                      onCompare={toggleComparison}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-32 bg-gray-50 rounded-[3rem]">
                  <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Heart size={40} className="text-red-200" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">Your wishlist is empty</h3>
                  <p className="text-gray-500 mt-2 max-w-sm mx-auto">Save products you love to keep track of them and get notified about price drops.</p>
                  <button 
                    onClick={() => setView('home')}
                    className="mt-8 bg-orange-500 text-white px-8 py-4 rounded-2xl font-black shadow-xl shadow-orange-500/20 active:scale-95 transition-all"
                  >
                    Discover Products
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {view === 'admin' && (
            <motion.div 
              key="admin"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-black flex items-center gap-3">
                    <BarChart3 size={32} className="text-orange-500" />
                    Growth Dashboard
                  </h2>
                  <p className="text-gray-500 mt-1">Manage your Amazon Finds ecosystem and content strategy.</p>
                </div>
                <button 
                  onClick={() => setView('home')}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-600 px-6 py-3 rounded-2xl font-bold transition-all"
                >
                  Exit Admin
                </button>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white border border-gray-100 p-6 rounded-[2rem] shadow-sm">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total Clicks</span>
                  <div className="text-4xl font-black mt-2 text-orange-500">
                    {Object.values(analytics).reduce((acc: number, curr: any) => acc + (Number(curr.clicks) || 0), 0)}
                  </div>
                  <div className="text-xs text-green-500 font-bold mt-2 flex items-center gap-1">
                    <TrendingUp size={12} /> +12% from last week
                  </div>
                </div>
                <div className="bg-white border border-gray-100 p-6 rounded-[2rem] shadow-sm">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total Views</span>
                  <div className="text-4xl font-black mt-2 text-gray-900">
                    {Object.values(analytics).reduce((acc: number, curr: any) => acc + (Number(curr.views) || 0), 0)}
                  </div>
                  <div className="text-xs text-gray-400 font-bold mt-2">Organic Reach</div>
                </div>
                <div className="bg-white border border-gray-100 p-6 rounded-[2rem] shadow-sm">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Avg. CTR</span>
                  <div className="text-4xl font-black mt-2 text-blue-500">
                    {(() => {
                      const totalClicks = Object.values(analytics).reduce((acc: number, curr: any) => acc + (Number(curr.clicks) || 0), 0) as number;
                      const totalViews = Object.values(analytics).reduce((acc: number, curr: any) => acc + (Number(curr.views) || 0), 0) as number;
                      return ((totalClicks / (totalViews || 1)) * 100).toFixed(1);
                    })()}%
                  </div>
                  <div className="text-xs text-blue-400 font-bold mt-2">High Conversion</div>
                </div>
                <div className="bg-white border border-gray-100 p-6 rounded-[2rem] shadow-sm">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Est. Revenue</span>
                  <div className="text-4xl font-black mt-2 text-green-600">
                    ${(Number(Object.values(analytics).reduce((acc: number, curr: any) => acc + (Number(curr.clicks) || 0), 0)) * 0.45).toFixed(2)}
                  </div>
                  <div className="text-xs text-green-500 font-bold mt-2">Based on $0.45 EPC</div>
                </div>
              </div>

              {/* Growth Hub - Video Scripts */}
              <div className="bg-gray-900 rounded-[3rem] p-8 md:p-12 text-white">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h3 className="text-2xl font-black">Viral Content Hub</h3>
                    <p className="text-gray-400 mt-1">Done-for-you scripts to scale your TikTok/Reels.</p>
                  </div>
                  <div className="bg-orange-500 px-4 py-2 rounded-xl text-xs font-bold">30 SCRIPTS READY</div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {VIDEO_SCRIPTS.slice(0, 4).map(script => (
                    <div key={script.id} className="bg-white/5 border border-white/10 p-6 rounded-3xl hover:bg-white/10 transition-all">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-[10px] font-black uppercase tracking-widest text-orange-500">Script #{script.id}</span>
                        <button className="text-white/40 hover:text-white"><ArrowUpRight size={16} /></button>
                      </div>
                      <h4 className="font-bold text-lg mb-2">{script.title}</h4>
                      <div className="space-y-3 text-sm">
                        <p><span className="text-orange-400 font-bold">HOOK:</span> {script.hook}</p>
                        <p><span className="text-gray-400">PROBLEM:</span> {script.problem}</p>
                        <p><span className="text-gray-400">DEMO:</span> {script.demoIdea}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Product Performance Table */}
              <div className="bg-white border border-gray-100 rounded-[2.5rem] overflow-hidden shadow-sm">
                <div className="p-8 border-b border-gray-50 flex items-center justify-between">
                  <h3 className="text-xl font-black">Top Performing Finds</h3>
                  <Badge variant="trending">Real-time Performance</Badge>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 text-xs font-bold text-gray-400 uppercase tracking-widest">
                      <tr>
                        <th className="px-8 py-5">Product</th>
                        <th className="px-8 py-5">Category</th>
                        <th className="px-8 py-5">Views</th>
                        <th className="px-8 py-5">Clicks</th>
                        <th className="px-8 py-5">CTR</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {products.sort((a, b) => (Number(analytics[b.id]?.clicks) || 0) - (Number(analytics[a.id]?.clicks) || 0)).slice(0, 10).map(p => (
                        <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-8 py-5">
                            <div className="flex items-center gap-4">
                              <img src={p.image} className="w-12 h-12 rounded-xl object-cover" alt="" />
                              <span className="font-bold text-sm">{p.title}</span>
                            </div>
                          </td>
                          <td className="px-8 py-5 text-sm text-gray-500">{p.category}</td>
                          <td className="px-8 py-5 text-sm font-medium">{Number(analytics[p.id]?.views) || 0}</td>
                          <td className="px-8 py-5 text-sm font-bold text-orange-500">{Number(analytics[p.id]?.clicks) || 0}</td>
                          <td className="px-8 py-5">
                            <div className="flex items-center gap-3">
                              <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-orange-500" 
                                  style={{ width: `${Math.min(((Number(analytics[p.id]?.clicks) || 0) / (Number(analytics[p.id]?.views) || 1)) * 100, 100)}%` }}
                                />
                              </div>
                              <span className="text-xs font-bold">
                                {(((Number(analytics[p.id]?.clicks) || 0) / (Number(analytics[p.id]?.views) || 1)) * 100).toFixed(1)}%
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Comparison Modal */}
        <AnimatePresence>
          {comparisonIds.length >= 2 && (
            <ComparisonModal 
              products={products.filter(p => comparisonIds.includes(p.id))}
              onClose={() => setComparisonIds([])}
            />
          )}
        </AnimatePresence>

        {/* Comparison Bar (Sticky) */}
        <AnimatePresence>
          {comparisonIds.length > 0 && (
            <motion.div 
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              exit={{ y: 100 }}
              className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[80] bg-gray-900 text-white px-6 py-4 rounded-[2rem] shadow-2xl flex items-center gap-6 border border-white/10 backdrop-blur-xl"
            >
              <div className="flex items-center gap-2">
                <div className="flex -space-x-3">
                  {comparisonIds.map(id => (
                    <img 
                      key={id} 
                      src={products.find(p => p.id === id)?.image} 
                      className="w-10 h-10 rounded-full border-2 border-gray-900 object-cover" 
                      alt="" 
                    />
                  ))}
                </div>
                <span className="text-sm font-bold ml-2">{comparisonIds.length} items to compare</span>
              </div>
              <div className="h-8 w-px bg-white/10" />
              <div className="flex gap-3">
                <button 
                  onClick={() => setComparisonIds([])}
                  className="text-xs font-bold text-gray-400 hover:text-white"
                >
                  Clear
                </button>
                <button 
                  onClick={() => {
                    if (comparisonIds.length < 2) {
                      alert('Select at least 2 items to compare');
                    }
                  }}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all active:scale-95"
                >
                  Compare Now
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-100 py-16 mt-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white">
                  <ShoppingCart size={24} strokeWidth={2.5} />
                </div>
                <span className="text-xl font-black tracking-tighter">AMAZON<span className="text-orange-500">FINDS</span></span>
              </div>
              <p className="text-gray-500 max-w-sm leading-relaxed">
                We find the best, most useful, and viral products on Amazon so you don't have to. 
                Our team tests hundreds of items to bring you only the ones that actually make life easier.
              </p>
              <div className="flex gap-4 mt-8">
                {['Instagram', 'TikTok', 'YouTube', 'Facebook'].map(social => (
                  <a key={social} href="#" className="w-10 h-10 bg-white border border-gray-200 rounded-xl flex items-center justify-center text-gray-400 hover:text-orange-500 hover:border-orange-200 transition-all">
                    <span className="sr-only">{social}</span>
                    <div className="w-5 h-5 bg-current rounded-sm opacity-20" />
                  </a>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-black text-sm uppercase tracking-widest mb-6">Quick Links</h4>
              <ul className="space-y-4">
                <li><button onClick={() => setView('home')} className="text-gray-500 hover:text-orange-500 font-medium transition-colors">Home</button></li>
                <li><button onClick={() => setView('video-feed')} className="text-gray-500 hover:text-orange-500 font-medium transition-colors">Video Feed</button></li>
                <li><button onClick={() => setView('wishlist')} className="text-gray-500 hover:text-orange-500 font-medium transition-colors">Wishlist</button></li>
                <li><button onClick={() => setView('admin')} className="text-gray-500 hover:text-orange-500 font-medium transition-colors">Analytics</button></li>
              </ul>
            </div>

            <div>
              <h4 className="font-black text-sm uppercase tracking-widest mb-6">Categories</h4>
              <ul className="space-y-4">
                {CATEGORIES.slice(0, 4).map(cat => (
                  <li key={cat.name}>
                    <button 
                      onClick={() => { setSelectedCategory(cat.name); setView('home'); window.scrollTo(0, 0); }}
                      className="text-gray-500 hover:text-orange-500 font-medium transition-colors"
                    >
                      {cat.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-200 mt-16 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-400 font-medium">© 2026 Amazon Finds. All rights reserved.</p>
            <p className="text-[10px] text-gray-400 max-w-md text-center md:text-right">
              As an Amazon Associate, we earn from qualifying purchases. Amazon and the Amazon logo are trademarks of Amazon.com, Inc. or its affiliates.
            </p>
          </div>
        </div>
      </footer>

      {/* Mobile Sticky CTA */}
      <AnimatePresence>
        {view === 'home' && (
          <motion.div 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-6 left-6 right-6 z-40 md:hidden"
          >
            <button 
              onClick={() => {
                const el = document.getElementById('explore');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full bg-gray-900 text-white py-4 rounded-2xl font-black shadow-2xl flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              👉 EXPLORE TODAY'S FINDS
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
