export interface VideoScript {
  id: number;
  title: string;
  hook: string;
  problem: string;
  demoIdea: string;
  cta: string;
}

export const VIDEO_SCRIPTS: VideoScript[] = [
  {
    id: 1,
    title: "Electric Spin Scrubber",
    hook: "Stop breaking your back scrubbing the tub!",
    problem: "Scrubbing the bathroom is the worst chore ever.",
    demoIdea: "Show a dirty tub, then show the scrubber effortlessly cleaning it in seconds.",
    cta: "Link in bio to save your back!"
  },
  {
    id: 2,
    title: "Magnetic Measuring Spoons",
    hook: "The last measuring spoons you will ever buy.",
    problem: "Cluttered drawers and lost measuring spoons.",
    demoIdea: "Show a messy drawer, then show the spoons snapping together magnetically.",
    cta: "Grab these in my bio!"
  },
  {
    id: 3,
    title: "Portable Car Vacuum",
    hook: "Keep your car spotless with zero effort.",
    problem: "Car crumbs are impossible to get out.",
    demoIdea: "Show a car seat full of crumbs, then the vacuum sucking them all up.",
    cta: "Link in bio for a clean car!"
  },
  {
    id: 4,
    title: "Silicone Faucet Mat",
    hook: "This $10 find saved my kitchen counters.",
    problem: "Water pooling around the kitchen faucet.",
    demoIdea: "Show water splashing, then the mat draining it back into the sink.",
    cta: "Kitchen must-have in bio!"
  },
  {
    id: 5,
    title: "Motion Sensor Closet Light",
    hook: "Stop fumbling in the dark for your clothes.",
    problem: "Dark closets where you can't see anything.",
    demoIdea: "Open a dark closet, lights snap on automatically. No wiring needed.",
    cta: "Link in bio!"
  },
  {
    id: 6,
    title: "Desktop Vacuum",
    hook: "The cutiest way to clean your desk.",
    problem: "Keyboard crumbs and dust.",
    demoIdea: "Show a ladybug-shaped vacuum cleaning a keyboard.",
    cta: "Desk essential in bio!"
  },
  {
    id: 7,
    title: "Reusable Lint Roller",
    hook: "Stop buying those sticky paper rolls.",
    problem: "Pet hair everywhere and constant waste.",
    demoIdea: "Roll over a hairy couch, then wash the roller with water and it's sticky again.",
    cta: "Save money with the link in bio!"
  },
  {
    id: 8,
    title: "Bag Sealer",
    hook: "Keep your chips fresh forever.",
    problem: "Stale snacks because of bad clips.",
    demoIdea: "Show a half-eaten bag of chips, then seal it perfectly with the heat sealer.",
    cta: "Snack saver in bio!"
  },
  {
    id: 9,
    title: "Bed Sheet Tucker",
    hook: "Hotel-style beds in 30 seconds.",
    problem: "Hurting your fingers tucking in sheets.",
    demoIdea: "Show the tool sliding under the mattress to tuck the sheet perfectly.",
    cta: "Link in bio for better sleep!"
  },
  {
    id: 10,
    title: "Screen Cleaner Mist",
    hook: "Your phone screen is disgusting.",
    problem: "Fingerprints and smudges on screens.",
    demoIdea: "Spray the mist, wipe with the built-in microfiber cloth. Instant shine.",
    cta: "Clean your screen with the link in bio!"
  },
  // ... adding more to reach 30
  ...Array.from({ length: 20 }).map((_, i) => ({
    id: i + 11,
    title: `Viral Find #${i + 11}`,
    hook: "You didn't know you needed this until now.",
    problem: "A common daily annoyance solved.",
    demoIdea: "Show the product in action solving a specific problem.",
    cta: "Check it out in my bio!"
  }))
];
